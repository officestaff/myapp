package com.cg.faculty.exception;

public class FacultyException extends Exception{
	 
	public FacultyException(){
		super();
	}
	public FacultyException(String  message) {
		super(message);
	}
}
