package com.cg.faculty.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="Faculty_Details")
public class Faculty {
	   @Id
	   @Column(name="facultyId")
       private String id;
	   @NotEmpty(message="name is mandatory")
       private String name;
	   @NotEmpty(message="subject is mandatory")
       private String subject;
	   @NotEmpty(message="expertise is mandatory")
       private String expertise;
	   @NotEmpty(message="gender is mandatory")
       private String gender;
	   @Min(value=1,message="name should be between 1 and 5")
	   @Max(value=5,message="name should be between 1 and 5")
       private int grade;
       private String remarks;
       @Min(value=0)
       private int feedback;
       public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getExpertise() {
		return expertise;
	}
	public void setExpertise(String expertise) {
		this.expertise = expertise;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public int getGrade() {
		return grade;
	}
	public void setGrade(int grade) {
		this.grade = grade;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public int getFeedback() {
		return feedback;
	}
	public void setFeedback(int feedback) {
		this.feedback = feedback;
	}
}
