package com.cg.faculty.dao;

import java.math.BigDecimal;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.faculty.bean.Faculty;
import com.cg.faculty.exception.FacultyException;
@Repository
public class FacultyDaoImpl implements FacultyDao {
    @PersistenceContext
    EntityManager em;
	@Override
	public String addFaculty(Faculty faculty) throws FacultyException {
		String subject=faculty.getSubject();
		String code=subject.substring(0, 1);
		try{
			
			if(code.equals("J")){
				
			
		String strQuery="SELECT JAVASEQ.NEXTVAL FROM DUAL";
		Query query=em.createNativeQuery(strQuery);
		BigDecimal ret=(BigDecimal) query.getSingleResult();
		code=code+ret;
		faculty.setId(code);
		em.persist(faculty);
		}
			if(code.equals("M")){
				
				String strQuery="SELECT MICROSOFTSEQ.NEXTVAL FROM DUAL";
				Query query=em.createNativeQuery(strQuery);
				BigDecimal ret=(BigDecimal) query.getSingleResult();
				code=code+ret;
				faculty.setId(code);
				em.persist(faculty);
			}
		
		if(code.equals("I")){
			
			String strQuery="SELECT IBMSEQ.NEXTVAL FROM DUAL";
			Query query=em.createNativeQuery(strQuery);
			BigDecimal ret=(BigDecimal) query.getSingleResult();
			code=code+ret;
			faculty.setId(code);
			em.persist(faculty);
		}
		if(code.equals("C")){
			
			String strQuery="SELECT CISCOSEQ.NEXTVAL FROM DUAL";
			Query query=em.createNativeQuery(strQuery);
			BigDecimal ret=(BigDecimal) query.getSingleResult();
			code=code+ret;
			faculty.setId(code);
			em.persist(faculty);
		}
		}
		catch(Exception ex){
			throw new FacultyException(ex.getMessage());
		}
		return code;
	}

}
