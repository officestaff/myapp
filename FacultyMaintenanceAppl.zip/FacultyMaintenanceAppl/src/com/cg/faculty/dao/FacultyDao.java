package com.cg.faculty.dao;

import com.cg.faculty.bean.Faculty;
import com.cg.faculty.exception.FacultyException;

public interface FacultyDao {
       String addFaculty(Faculty faculty) throws FacultyException;
}
