package com.cg.faculty.controller;

import java.util.Date;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cg.faculty.bean.Faculty;
import com.cg.faculty.exception.FacultyException;
import com.cg.faculty.service.FacultyService;

@Controller
public class FacultyController {
	   @Autowired
	   FacultyService service;
	   @RequestMapping("/")
       public String showIndex(){
		return "home";
    	   
       }
	   @RequestMapping("/addFaculty")
	   public ModelAndView showAddForm(){
		   ModelAndView mv=new ModelAndView("add_faculty");
		   Faculty faculty=new Faculty();
		   faculty.setRemarks("Date Joined :"+new Date());
		   mv.addObject("faculty",faculty);
		   String[] subjects=new String[] {"Java","Microsoft","Cisco","IBM"};
		   mv.addObject("subjects",subjects);
		return mv;
		   
	   }
	   @RequestMapping("/add")
	   public ModelAndView addFaculty
	      (@Valid @ModelAttribute("faculty") Faculty faculty,BindingResult result){
		   ModelAndView mv=new ModelAndView();
		   if(result.hasErrors())
		   {
			   String[] subjects=new String[] {"Java","Microsoft","Cisco","IBM"};
			   mv.addObject("subjects",subjects);
			   mv.setViewName("add_faculty");
			   return mv;
		   }
		   try {
			   if(faculty.getFeedback()==0){
				   faculty.setRemarks(faculty.getRemarks()+"Feedback to be taken");
			   }
			String facultyCode=service.addFaculty(faculty);
			mv.setViewName("success");
			mv.addObject("id", facultyCode);
		} catch (FacultyException e) {
			mv.setViewName("error");
			mv.addObject("exception", "An Error Occured "+e.getMessage());
		}
			return mv;
		   
	   }
}
