package com.cg.faculty.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.faculty.bean.Faculty;
import com.cg.faculty.dao.FacultyDao;
import com.cg.faculty.exception.FacultyException;
@Service
@Transactional
public class FacultyServiceImpl implements FacultyService {
    @Autowired
    FacultyDao dao;
	@Override
	public String addFaculty(Faculty faculty) throws FacultyException {
		// TODO Auto-generated method stub
		return dao.addFaculty(faculty);
	}
	
}
