package com.cg.faculty.service;

import com.cg.faculty.bean.Faculty;
import com.cg.faculty.exception.FacultyException;

public interface FacultyService {
	  String addFaculty(Faculty faculty) throws FacultyException;
}
