package com.capgemini.hbms.dao;

public interface QueryMapperRoom {

		public static final String CHECK_ROOM_AVAILABITY = "SELECT availability from roomdetails WHERE room_id = ?";
		
		public static final String GET_ROOM_IDS = "SELECT room_id from roomdetails";
		
		public static final String GET_ROOM_AMOUNT = "SELECT per_night_rate from roomdetails where room_id = ?";
		
		public static final String SHOW_ROOMID_HOTELID = "SELECT hotel_id,room_id from roomdetails";
		
		public static final String GET_ROOM_DETAIL = "SELECT * from roomdetails WHERE room_id = ?";
		
		public static final String SHOW_ROOMDETAILS = "SELECT * from roomdetails where hotel_id = ?";
		
		public static final String INSERT_ROOM = "INSERT INTO roomdetails (hotel_id,room_id,room_no,room_type,per_night_rate,availability,photo) VALUES (?,?,?,?,?,?,?)";

		public static final String DELETE_ROOM = "DELETE FROM roomdetails WHERE room_id = ?";
		
		public static final String MODIFY_ROOM = "UPDATE roomdetails SET room_no = ? , room_type = ? ,"
				+ " per_night_rate = ? , availability = ?"
				+ " WHERE (room_id = ? AND hotel_id = ?)";
	}


