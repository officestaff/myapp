package com.capgemini.hbms.dao;



public interface QueryMapperBooking {

	public static final String INSERT_BOOKING_DETAILS = "INSERT INTO bookingdetails values(booking_id_sequence.nextval,?,?,?,?,?,?,?)";

	public static final String SHOW_BOOKINGID = "SELECT booking_id_sequence.CURRVAL FROM DUAL";

	public static final String GET_BOOKING_DETAIL = "SELECT * from bookingdetails WHERE booking_id = ?";

	public static final String GET_BOOKING_DETAILS = "SELECT * from bookingdetails WHERE user_id = ?";
	
	public static final String GET_ALL_BOOKING_DETAILS = "SELECT * from bookingdetails";

	public static final String GET_BOOKING_DETAILS_BY_DATE = "SELECT * from bookingdetails WHERE booked_from = ?";
}

