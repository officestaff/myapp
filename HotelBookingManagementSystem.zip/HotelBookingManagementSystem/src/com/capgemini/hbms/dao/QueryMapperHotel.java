package com.capgemini.hbms.dao;

public interface QueryMapperHotel {

	public static final String SHOW_HOTELS = "SELECT hotel_id,city,hotel_name,address,"
			+ "description,avg_rate_per_night,phone_no1,phone_no2,"
			+ "rating,email,fax FROM hotel";
	
	
	
	public static final String SHOW_HOTELDETAILS = "SELECT * from hotel where hotel_id = ?";
	
	
	public static final String INSERT_HOTEL = "INSERT INTO hotel (hotel_id,city,hotel_name,address,"
			+ "description,avg_rate_per_night,phone_no1,phone_no2,"
			+ "rating,email,fax) VALUES (hotel_id_sequence.nextval,?,?,?,?,?,?,?,?,?,?)";
	
	public static final String SHOW_HOTEL_ID = "SELECT hotel_id_sequence.CURRVAL FROM DUAL";
	
	public static final String DELETE_HOTEL = "DELETE FROM hotel WHERE hotel_id = ?";
	
	public static final String MODIFY_HOTEL = "UPDATE hotel SET city = ? , hotel_name = ? , address = ? ,"
			+ " description = ? , avg_rate_per_night = ? , phone_no1 = ? , phone_no2 = ? ,"
			+ " rating = ? , email = ? , fax = ? WHERE hotel_id = ?";
}
	
	

