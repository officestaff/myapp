package com.capgemini.hbms.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;



import org.apache.log4j.Logger;

import com.capgemini.hbms.bean.BookingBean;
import com.capgemini.hbms.bean.RoomDetailsBean;
import com.capgemini.hbms.exception.HbmsException;
import com.capgemini.hbms.util.DbUtil;

public class BookingDaoImpl implements IBookingDao {

	BookingBean bookingBean = new BookingBean();
	RoomDetailsBean roomDetailsBean = new RoomDetailsBean();

	Logger logger = Logger.getLogger(BookingDaoImpl.class);
	@Override
	public String bookHotelRoom(BookingBean bookingBean) throws HbmsException {
		
		
		
		
		String bookingId = null;
		int records = 0;

		try (Connection conn = DbUtil.getConnection(); // DataBase Connection
				PreparedStatement preparedStatement = conn
						.prepareStatement(QueryMapperBooking.INSERT_BOOKING_DETAILS); // Preparing
																								// query
		) {
			java.sql.Date sbookFrom = java.sql.Date.valueOf(bookingBean.getBookedFrom());
			java.sql.Date sbookTo = java.sql.Date.valueOf(bookingBean.getBookedTo());
			// Giving values to query statement
			preparedStatement.setString(1, bookingBean.getRoomId());
			preparedStatement.setString(2, bookingBean.getUserId());
			preparedStatement.setDate(3, sbookFrom);
			preparedStatement.setDate(4, sbookTo);
			preparedStatement.setInt(5, bookingBean.getNoOfAdults());
			preparedStatement.setInt(6, bookingBean.getNoOfChildren());
			preparedStatement.setDouble(7, bookingBean.getAmount());

			records = preparedStatement.executeUpdate(); // Executing the query

			if (records > 0) { // Checking for the record retrieval
				PreparedStatement preparePatientID = conn
						.prepareStatement(QueryMapperBooking.SHOW_BOOKINGID); // Preparing
																						// query

				ResultSet bookingIdRecord = preparePatientID.executeQuery(); // Execute
																				// query

				if (bookingIdRecord.next()) {
					bookingId = bookingIdRecord.getString(1);
					logger.info("BookingDetailsDAO : Hotel Booked (booking details inserted) and booking Id generated !!");
				}
			}
			
		} catch (SQLException sqlEx) {
			logger.info("BookingDetailsDAO : Hotel couldn't booked (could not insert)\n" + sqlEx.getMessage());
			throw new HbmsException(sqlEx.getMessage()); // Throws error
		}

		return bookingId;

	}

	@Override
	public List<BookingBean> getAllBookingDetails() throws HbmsException {
		
		
		List<BookingBean> bookingsList = new ArrayList<BookingBean>();
		

		try (Connection conn = DbUtil.getConnection(); // DataBase Connection
				PreparedStatement preparedStatement = conn
						.prepareStatement(QueryMapperBooking.GET_ALL_BOOKING_DETAILS); // Preparing
																				// query
		) {

			ResultSet rs = preparedStatement.executeQuery(); // Executing the
																// query
			while (rs.next()) {
				String bookingId = rs.getString(1);
				String roomId = rs.getString(2);
				String userId = rs.getString(3);
				LocalDate bookedFrom = rs.getDate(4).toLocalDate();
				LocalDate bookedTo = rs.getDate(5).toLocalDate();
				int noOfAdults = rs.getInt(6);
				int noOfChildren = rs.getInt(7);
				double amount = rs.getDouble(8);
				

				bookingBean = new BookingBean(bookingId,roomId,userId,bookedFrom,bookedTo,noOfAdults,noOfChildren,amount);
				bookingsList.add(bookingBean);
			}
			logger.info("BookingDetailsDAO : Retrieved all booking details !!");
			
		} catch (SQLException sqlEx) {
			logger.info("BookingDetailsDAO : Couldn't retrieve all booking details\n" + sqlEx.getMessage());
			throw new HbmsException(sqlEx.getMessage()); // Throws error
		}
		
		return bookingsList;
	}

	@Override
	public BookingBean getBookingDetail(String bookingId) throws HbmsException {
		
		

		try (Connection conn = DbUtil
				.getConnection(); // DataBase Connection
				PreparedStatement preparedStatement = conn
						.prepareStatement(QueryMapperBooking.GET_BOOKING_DETAIL); // Preparing
																							// query
		) {

			preparedStatement.setString(1, bookingId);
			ResultSet rs = preparedStatement.executeQuery(); // Executing the
																// query

			while (rs.next()) {
				String bookingID = rs.getString(1);
				String roomId = rs.getString(2);
				String userId = rs.getString(3);
				LocalDate bookedFrom = rs.getDate(4).toLocalDate();
				LocalDate bookedTo = rs.getDate(5).toLocalDate();
				int noOfAdults = rs.getInt(6);
				int noOfChildren = rs.getInt(7);
				double amount = rs.getDouble(8);
				

				bookingBean = new BookingBean(bookingID,roomId,userId,bookedFrom,bookedTo,noOfAdults,noOfChildren,amount);
			}
			logger.info("BookingDetailsDAO : Retrieved booking detail based on booking Id !!");

		} catch (SQLException sqlEx) {
			logger.info("BookingDetailsDAO : Couldn't retrieve booking detail based on booking Id\n" + sqlEx.getMessage());
			throw new HbmsException(sqlEx.getMessage()); // Throws error
		}
		return bookingBean;
	}

	@Override
	public List<BookingBean> getBookingDetails(String userId)
			throws HbmsException {
	
		
		List<BookingBean> bookingList = new ArrayList<BookingBean>();

		try (Connection conn = DbUtil
				.getConnection(); // DataBase Connection
				PreparedStatement preparedStatement = conn
						.prepareStatement(QueryMapperBooking.GET_BOOKING_DETAILS); // Preparing
																							// query
		) {

			preparedStatement.setString(1, userId);
			ResultSet rs = preparedStatement.executeQuery(); // Executing the
																// query

			while (rs.next()) {
				String bookingId = rs.getString(1);
				String roomId = rs.getString(2);
				String userID = rs.getString(3);
				LocalDate bookedFrom = rs.getDate(4).toLocalDate();
				LocalDate bookedTo = rs.getDate(5).toLocalDate();
				int noOfAdults = rs.getInt(6);
				int noOfChildren = rs.getInt(7);
				double amount = rs.getDouble(8);
				

				bookingBean = new BookingBean(bookingId,roomId,userID,bookedFrom,bookedTo,noOfAdults,noOfChildren,amount);
				bookingList.add(bookingBean);
			}
			logger.info("BookingDetailsDAO : Retrieved booking detail based on user Id !!");
		} catch (SQLException sqlEx) {
			logger.info("BookingDetailsDAO : Couldn't retrieve booking detail based on user Id\n" + sqlEx.getMessage());
			throw new HbmsException(sqlEx.getMessage()); // Throws error
		}
		return bookingList;
	
	
	
	}

	@Override
	public List<BookingBean> getBookingDetailsByDate(LocalDate fromDate)
			throws HbmsException {
	
	
		
		List<BookingBean> bookingsList = new ArrayList<BookingBean>();
		
		try (Connection conn = DbUtil
				.getConnection(); // DataBase Connection
				PreparedStatement preparedStatement = conn
						.prepareStatement(QueryMapperBooking.GET_BOOKING_DETAILS_BY_DATE); // Preparing
																							// query
		) {
			
			Date fromDatesql = java.sql.Date.valueOf(fromDate);
			
			preparedStatement.setDate(1, fromDatesql);
			
			ResultSet rs = preparedStatement.executeQuery(); // Executing the
																// query

			while (rs.next()) {
				String bookingID = rs.getString(1);
				String roomId = rs.getString(2);
				String userId = rs.getString(3);
				LocalDate bookedFrom = rs.getDate(4).toLocalDate();
				LocalDate bookedTo = rs.getDate(5).toLocalDate();
				int noOfAdults = rs.getInt(6);
				int noOfChildren = rs.getInt(7);
				double amount = rs.getDouble(8);
				

				bookingBean = new BookingBean(bookingID,roomId,userId,bookedFrom,bookedTo,noOfAdults,noOfChildren,amount);
				bookingsList.add(bookingBean);
			}
			logger.info("BookingDetailsDAO : Retrieved booking detail based on booking date !!");
		} catch (SQLException sqlEx) {
			logger.info("BookingDetailsDAO : Couldn't retrieve booking detail based on booking date\n" + sqlEx.getMessage());
			throw new HbmsException(sqlEx.getMessage()); // Throws error
		}
		return bookingsList;
		
	}

}
