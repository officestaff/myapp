package com.capgemini.hbms.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;












import com.capgemini.hbms.bean.UserBean;
import com.capgemini.hbms.dao.BookingDaoImpl;
import com.capgemini.hbms.dao.IBookingDao;
import com.capgemini.hbms.dao.IUserDao;
import com.capgemini.hbms.dao.QueryMapperUser;
import com.capgemini.hbms.dao.UserDaoImpl;
import com.capgemini.hbms.exception.HbmsException;
import com.capgemini.hbms.util.DbUtil;

public class UserServiceImpl implements IUserService{

	//IUserDao userDao;

	IUserDao userDao = new UserDaoImpl();
	IBookingDao bookDao=new BookingDaoImpl();
	@Override
	public int RegisterUser(UserBean bean) throws HbmsException {
	
		return userDao.RegisterUser(bean);
	}
	@Override
	public boolean LoginCheck(UserBean userBean) throws HbmsException {
		

		boolean validUser = false;
		List<UserBean> userCredentialsLists = userDao.getUserCredentials();
		
		for(UserBean userCredentialsList : userCredentialsLists){
			if(userCredentialsList.getUserId().equals(userBean.getUserId())&&userCredentialsList.getPassword().equals(userBean.getPassword())&&userCredentialsList.getRole().equals(userBean.getRole())){
				validUser = true;
				break;
			}
		}
		System.out.println(validUser);
		return validUser;
		
			}
	
	public UserBean getUserDetails(String userId) throws HbmsException {
		
		return userDao.getUserDetails(userId);
	}
	/*@Override
	public int validateInputs(UserBean userBean) throws HbmsException {

		if(!userBean.getUserName().matches("[A-Z][A-Za-z]{1,19}"))
		{
			throw new HbmsException("Name should start with a capital letter and shold be minimum 20 characters ");
		}
		
		
		//checks whether entered phone number is 10 digit number
		if(!userBean.getMobileNo().matches("\\d{10}"))
		{
			throw new HbmsException("please enter valid Phone number");
		}
		
		if(!userBean.getPhone().matches("\\d{8}"))
		{
			throw new HbmsException("please enter valid Phone number");
		}
		return 1;
		
	}*/
	public boolean validateName(String userName) {
		boolean flag = false;
		if(userName.matches("[A-Z]{1}[a-z]{2,}"))
		{
			flag = true;
		}

		return flag;

	}
	public boolean validatePassword(String password) {
		boolean flag = false;
		if(password.matches("[A-Za-z0-9]{1,}[ @ - .]{1}[A-Za-z0-9]{1,}"))
		{
			flag = true;
		}
		return flag;
	}
	public boolean validateMobile(String mobileNo) {
		boolean flag = false;
		if(mobileNo.matches("\\d{10}"))
		{
			flag = true;
		}
		return flag;	
		}
	
	
	public boolean validatePhone(String phone) {
		boolean flag = false;
		if(phone.matches("\\d{8}"))
		{
			flag = true;
		}
		return flag;	
	}
	public boolean validateAddress(String address) {
		boolean flag = false;
		if(address.matches("[A-Za-z]*[- , /]*[0-9]*"))
		{
			flag = true;
		}
		return flag;
	}
	public boolean validateEmail(String email) {
		
		boolean flag = false;
		if(email.matches("[a-z0-9]{1,}@[a-z]{3,}.com"))
		{
			flag = true;
		}
		return flag;
	}
		
	

	}
	
	
	
	
	

