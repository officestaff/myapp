package com.capgemini.hbms.service;

import java.util.List;

import com.capgemini.hbms.bean.HotelBean;
import com.capgemini.hbms.exception.HbmsException;

public interface IHotelService {

	List<HotelBean> viewHotelsList() throws HbmsException;

	List<HotelBean> viewHotels(String city) throws HbmsException;

	HotelBean viewHotel(String hotelId) throws HbmsException;

	int insertHotel(HotelBean hotelDetailsBean) throws HbmsException;

	boolean deleteHotel(String hotelId) throws HbmsException;

	boolean modifyHotel(HotelBean hotelDetailsBean) throws HbmsException;

	

}
