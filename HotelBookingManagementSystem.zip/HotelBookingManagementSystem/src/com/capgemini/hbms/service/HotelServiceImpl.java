package com.capgemini.hbms.service;

import java.util.ArrayList;
import java.util.List;

import com.capgemini.hbms.bean.HotelBean;
import com.capgemini.hbms.dao.BookingDaoImpl;
import com.capgemini.hbms.dao.HotelDaoImpl;
import com.capgemini.hbms.dao.IBookingDao;
import com.capgemini.hbms.dao.IHotelDao;
import com.capgemini.hbms.exception.HbmsException;

public class HotelServiceImpl implements IHotelService{

	IHotelDao hotelDetailsDao = new HotelDaoImpl();
	IBookingDao bookingDetailsDao = new BookingDaoImpl();
	
	@Override
	public List<HotelBean> viewHotels(String city) throws HbmsException {
		
		List<HotelBean> listOfHotels = hotelDetailsDao.viewHotels();
		List<HotelBean> hotelsBasedOnCity = new ArrayList<HotelBean>();
		
		for(HotelBean hotel : listOfHotels){
			if(hotel.getCity().equalsIgnoreCase(city)){
				hotelsBasedOnCity.add(hotel);
			}
		}
		return hotelsBasedOnCity;
	}
	
	

	@Override
	public int insertHotel(HotelBean hotelDetailsBean)
			throws HbmsException {
		
		return hotelDetailsDao.insertHotel(hotelDetailsBean);
	}

	@Override
	public boolean deleteHotel(String hotelId) throws HbmsException {
		
		return hotelDetailsDao.deleteHotel(hotelId);
	}


	@Override
	public List<HotelBean> viewHotelsList() throws HbmsException {
		
		return hotelDetailsDao.viewHotels();
	}

	@Override
	public HotelBean viewHotel(String hotelId) throws HbmsException {
		return hotelDetailsDao.viewHotel(hotelId);
	
	}



	@Override
	public boolean modifyHotel(HotelBean hotelDetailsBean) throws HbmsException {
		
		return hotelDetailsDao.modifyHotel(hotelDetailsBean);
	}



	

	
	

}
