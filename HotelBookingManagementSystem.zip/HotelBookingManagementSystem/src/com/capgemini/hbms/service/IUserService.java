package com.capgemini.hbms.service;

import com.capgemini.hbms.bean.UserBean;
import com.capgemini.hbms.exception.HbmsException;

public interface IUserService {

	int RegisterUser(UserBean userDetails) throws HbmsException;

	boolean LoginCheck(UserBean userBean)throws HbmsException;

	public UserBean getUserDetails(String userId) throws HbmsException;

	//int validateInputs(UserBean userBean) throws HbmsException;




	
}
