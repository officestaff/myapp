package com.capgemini.hbms.service;

import java.time.LocalDate;
import java.util.List;

import com.capgemini.hbms.bean.BookingBean;

import com.capgemini.hbms.dao.BookingDaoImpl;
import com.capgemini.hbms.dao.IBookingDao;

import com.capgemini.hbms.exception.HbmsException;

public class BookingServiceImpl implements IBookingService{

	IBookingDao bookingDao= new BookingDaoImpl();
	
	@Override
	public BookingBean getBookingDetail(String bookingId) throws HbmsException {
		
		return bookingDao.getBookingDetail(bookingId);
	}
	
	@Override
	public String bookHotelRoom(BookingBean bookingDetailsBean)
			throws HbmsException {
	
		return bookingDao.bookHotelRoom(bookingDetailsBean);
	}

	@Override
	public List<BookingBean> getBookingDetails(String userId)
			throws HbmsException {
		List<BookingBean> bookingList = bookingDao.getBookingDetails(userId);
		return bookingList;
	}

	@Override
	public List<BookingBean> getAllBookingDetails() throws HbmsException {
		
		List<BookingBean> bookingList = bookingDao.getAllBookingDetails();
		return bookingList;
	}

	@Override
	public List<BookingBean> getBookingDetailsByDate(LocalDate fromDate) throws HbmsException {
		
		List<BookingBean> bookingList = bookingDao.getBookingDetailsByDate(fromDate);
		return bookingList;
	}

}
